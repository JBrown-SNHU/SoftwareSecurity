package Proj2Refactorcom.refactored_code_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RefactoredCodeSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
